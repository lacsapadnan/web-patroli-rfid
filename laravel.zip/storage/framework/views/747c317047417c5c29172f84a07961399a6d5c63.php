<script src="assets/js/vendors.min.js"></script>
<?php /**PATH D:\laragon\www\laravel\resources\views/includes/vendor.blade.php ENDPATH**/ ?>