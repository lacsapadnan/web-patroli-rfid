<link href="assets/css/app.min.css" rel="stylesheet">
<?php /**PATH D:\laragon\www\laravel\resources\views/includes/style.blade.php ENDPATH**/ ?>