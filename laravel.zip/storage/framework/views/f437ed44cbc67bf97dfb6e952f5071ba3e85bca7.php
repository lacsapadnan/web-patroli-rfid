<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <ul class="list-unstyle m-10 d-flex justify-content-center align-items-center">
                    <?php if($patroli == null || $patroli['end'] != null): ?>
                        <div class="col-sm-4 col-6 font-weight-semibold text-dark m-b-5 text-center">
                                <h3>Silahkan Tempelkan Kartu RFID Anda</h3>
                                <img src="<?php echo e(url('/assets/images/rfid.png')); ?>" style="width: 200px"> <br>
                                <img src="<?php echo e(url('/assets/images/animasi2.gif')); ?>" class="mt-2">
                        </div>
                    <?php else: ?>
                        <?php if($patroli->end == null): ?>
                            <div class="col-sm-6 col-6 font-weight-semibold text-dark m-b-5 text-center">
                                <span>Status: </span>
                                <span class="btn bg-success p-1 text-white badge" style="font-size: 80%">Laporan Patroli</span>
                            </div>
                            <div class="col-sm-6 col-6 font-weight-semibold text-dark m-b-5">
                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('selesai-patroli')); ?>" enctype="multipart/form-data" method="post">
                                    <?php echo csrf_field(); ?>
                                    <label for="photo">Foto Patroli</label>
                                    <input type="file" name="photo" id="photo" class="form-control">
                                    <label class="mt-4" for="report">Laporan Patroli</label>
                                    <textarea name="report" id="report" cols="30" rows="4" class="form-control" placeholder="Isi laporan patroli"></textarea>
                                    <button type="submit" class="btn btn-danger mt-3">Selesai</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\resources\views/pages/karyawan/patroli.blade.php ENDPATH**/ ?>