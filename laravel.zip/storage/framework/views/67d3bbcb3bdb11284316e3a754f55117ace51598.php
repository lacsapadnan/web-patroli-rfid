<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('includes.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Patroli - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/logo/favicon.png">

    <!-- page css -->
    <?php echo $__env->yieldPushContent('style'); ?>
    <!-- Core css -->
    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="app">
        <div class="layout">
            
            <?php echo $__env->make('parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            
            <?php echo $__env->make('parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            
            <div class="page-container">
                <div class="main-content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                
                 <?php echo $__env->make('parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>



        </div>
    </div>


    <!-- Core Vendors JS -->
    <?php echo $__env->make('includes.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- page js -->
    <?php echo $__env->yieldPushContent('script'); ?>

    <!-- Core JS -->
    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\laravel\resources\views/layouts/master.blade.php ENDPATH**/ ?>