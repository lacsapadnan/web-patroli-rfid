<footer class="footer">
<div class="footer-content">
    <p class="m-b-0">Copyright © 2019 Theme_Nate. All rights reserved.</p>
</div>
</footer>
<?php /**PATH D:\laragon\www\laravel\resources\views/parts/footer.blade.php ENDPATH**/ ?>