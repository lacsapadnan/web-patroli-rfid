<div class="side-nav">
    <div class="side-nav-inner">
        <ul class="side-nav-menu scrollable">
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="<?php echo e(route('dashboard')); ?>">
                    <span class="icon-holder">
                        <i class="anticon anticon-dashboard"></i>
                    </span>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                <li class="nav-item dropdown">
                    <a class="dropdown-toggle" href="<?php echo e(route('data-karyawan.index')); ?>">
                        <span class="icon-holder">
                            <i class="anticon anticon-user"></i>
                        </span>
                        <span class="title">Data Karyawan</span>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="dropdown-toggle" href="<?php echo e(route('laporan')); ?>">
                        <span class="icon-holder">
                            <i class="anticon anticon-table"></i>
                        </span>
                        <span class="title">Laporan Patroli</span>
                    </a>
                </li>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a class="dropdown-toggle" href="javascript:void(0);">
                        <span class="icon-holder">
                            <i class="anticon anticon-form"></i>
                        </span>
                        <span class="title">Patroli</span>
                        <span class="arrow">
                            <i class="arrow-icon"></i>
                        </span>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo e(route('patroli')); ?>">Patroli</a>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH D:\laragon\www\laravel\resources\views/parts/sidebar.blade.php ENDPATH**/ ?>