<script src="assets/js/app.min.js"></script>
<?php /**PATH D:\laragon\www\laravel\resources\views/includes/script.blade.php ENDPATH**/ ?>