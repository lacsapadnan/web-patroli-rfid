
<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-purple">
                                <i class="anticon anticon-user"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0"><?php echo e($karyawan); ?></h2>
                                <p class="m-b-0 text-muted">Karyawan</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="media align-items-center">
                            <div class="avatar avatar-icon avatar-lg avatar-purple">
                                <i class="anticon anticon-user"></i>
                            </div>
                            <div class="m-l-15">
                                <h2 class="m-b-0"><?php echo e($admin); ?></h2>
                                <p class="m-b-0 text-muted">Admin</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-7 col-sm-4">
                        <div class="d-md-flex align-items-center">
                            <div class="text-center text-sm-left ">
                                <div class="avatar avatar-image" style="width: 150px; height:150px">
                                    <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="">
                                </div>
                            </div>
                            <div class="text-center text-sm-left m-v-15 p-l-30">
                                <h2 class="m-b-5"><?php echo e(Auth::user()->name); ?></h2>
                                <p class="text-dark m-b-20">Posisi : <?php echo e(Auth::user()->role); ?></p>
                                <a href="<?php echo e(route('profile.show')); ?>"><button class="btn btn-primary btn-tone">Edit Profile</button></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-8">
                        <div class="row">
                            <div class="d-md-block d-none border-left col-1"></div>
                            <div class="col">
                                <ul class="list-unstyled m-t-10">
                                    <li class="row">
                                        <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                            <i class="m-r-auto text-primary anticon anticon-mail"></i>
                                            <span>Email: </span>
                                        </p>
                                        <p class="col font-weight-semibold"> <?php echo e(Auth::user()->email); ?></p>
                                    </li>
                                    <li class="row">
                                        <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                            <i class="m-r-auto text-primary anticon anticon-phone"></i>
                                            <span>No. Hp: </span>
                                        </p>
                                        <p class="col font-weight-semibold"> <?php echo e(Auth::user()->phone); ?></p>
                                    </li>
                                    <li class="row">
                                        <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                            <i class="m-r-auto text-primary anticon anticon-compass"></i>
                                            <span>Alamat: </span>
                                        </p>
                                        <p class="col font-weight-semibold"> <?php echo e(Auth::user()->address); ?></p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\resources\views/new_dashboard.blade.php ENDPATH**/ ?>