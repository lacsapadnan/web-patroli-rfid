<footer class="footer">
<div class="footer-content">
    <p class="m-b-0">Copyright © 2019 Theme_Nate. All rights reserved.</p>
</div>
</footer>
